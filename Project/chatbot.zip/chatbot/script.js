let chat_box=document.getElementById("Chat_box");
let send_button=document.getElementById("send");
let input_field=document.getElementById("input");

send_button.addEventListener("click",function(){
    let user_input=input_field.value;
    if(user_input!=""){
       let input= document.createElement("div");
       input.classList.add("messageBoxInput");
       input.textContent= user_input;
       chat_box.appendChild(input);
       let bot_reply= document.createElement("div");
       bot_reply.classList.add("messageBoxOutput");
       bot_reply.textContent= bot_response(user_input);
       chat_box.appendChild(bot_reply);

         input_field.value="";
    }
});

function bot_response(user_input){

     if(user_input.includes("hello") || user_input.includes("hi")){
        return "Hello! How can I assist you today?";
     }
        else if(user_input.includes("how are you")){
            return "I'm just a bot, but I'm here to help you!";
        }
        else if(user_input.includes("what is your name")){
            return "I am a DOM Chatbot created to assist you.";
        }
        else if(user_input.includes("bye") || user_input.includes("goodbye")){
            return "Goodbye! Have a great day!";
        }
        else if(user_input.includes("help")){
            return "Sure! What do you need help with?";
        }
        else if(user_input.includes("what can you do")){
            return "I can answer simple questions and have basic conversations. Try asking me something!";
        }
        else if(user_input.includes("thank you") || user_input.includes("thanks")){
            return "You're welcome! If you have any more questions, feel free to ask.";
        }
        else if(user_input.includes("how are u")){
            return "I'm just a bot, but I'm here to help you!";
        }
        else{
            return "I'm sorry, I don't understand that.I am just made for testing DOM manipulation not to answer complex questions.";
        }
}